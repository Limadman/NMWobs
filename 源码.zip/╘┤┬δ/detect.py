from ultralytics import YOLO
import os
import uuid
import numpy as np
import time
import cv2

# 全局变量记录最后一次警报时间
last_alert_time = 0
def check_barricade_alert(results, alert_cooldown=5):
    global last_alert_time
    current_time = time.time()

    if results and hasattr(results[0], 'boxes'):
        for box in results[0].boxes:
            cls = box.cls.cpu().numpy()
            conf = box.conf.cpu().numpy()
            if results[0].names[int(cls[0])] == 'barricade' and conf[0] >= 0.7:
                if current_time - last_alert_time > alert_cooldown:
                    last_alert_time = current_time
                    return True
    return False
def model_predict(source, project='runs/predict', name='exp'):
    global last_alert_time
    try:
        # 构建模型路径
        model_path = r'C:\Users\86130\Desktop\NMWobs\runs\train\exp5\weights\best.pt'
        # 检查模型文件是否存在
        if not os.path.exists(model_path):
            print(f"模型文件不存在: {model_path}")  # 调试信息
            return None
        # 加载模型
        model = YOLO(model_path)
        if isinstance(source, str):
            file_name = os.path.basename(source)
            save_path = None  # 不保存预测结果
        elif isinstance(source, np.ndarray):  # 处理视频帧的情况
            unique_id = uuid.uuid4().hex
            save_path = None  # 不保存预测结果
        else:
            raise ValueError("Unsupported source type")
        results = model.predict(
            source=source,
            save=False,  # 根据save_path决定是否保存预测结果
            imgsz=640,  # 输入图像的大小，可以是整数或w，h
            conf=0.25,  # 用于检测的目标置信度阈值（默认为0.25，用于预测，0.001用于验证）
            iou=0.45,  # 非极大值抑制 (NMS) 的交并比 (IoU) 阈值
            show=False,  # 如果可能的话，显示结果
            project=project,  # 项目名称
            name=name,  # 使用固定的目录名
            save_txt=False,  # 保存结果为 .txt 文件
            save_conf=True,  # 保存结果和置信度分数
            save_crop=False,  # 保存裁剪后的图像和结果
            show_labels=True,  # 在图中显示目标标签
            show_conf=True,  # 在图中显示目标置信度分数
            vid_stride=1,  # 视频帧率步长
            line_width=2,  # 调整边界框线条粗细（像素）
            visualize=False,  # 可视化模型特征
            augment=False,  # 对预测源应用图像增强
            agnostic_nms=False,  # 类别无关的NMS
            retina_masks=False,  # 使用高分辨率的分割掩码
            show_boxes=True,  # 在分割预测中显示边界框
        )
        # print(f"预测结果: {results}")  # 调试信息
        # if not results:
        #     print("预测结果为空")  # 调试信息
        #     return None
        if save_path is None:
            # 返回带有标注的帧
            annotated_frame = results[0].plot()

            # 检查是否需要触发警报
            alert_triggered = check_barricade_alert(results)
            if alert_triggered:
                # 添加红色警告覆盖层
                overlay = annotated_frame.copy()
                cv2.rectangle(overlay, (0, 0), (annotated_frame.shape[1], annotated_frame.shape[0]), (0, 0, 255), -1)
                cv2.addWeighted(overlay, 0.3, annotated_frame, 0.7, 0, annotated_frame)
                # 添加警告文字
                cv2.putText(annotated_frame, "WARNING!!!", (50, 100),
                            cv2.FONT_HERSHEY_SIMPLEX, 1.5, (255, 255, 255), 4)

            return annotated_frame

    except Exception as e:
        print(f"模型预测过程中发生错误: {str(e)}")
        return None

if __name__ == '__main__':
    # 用户选择输入源类型
    print("请选择输入源类型：")
    print("1. 图片")
    print("3. 摄像头")
    choice = input("请输入选项编号（1/3）：")

    if choice == '1':
        # 图片路径
        source = r'C:\Users\86130\Desktop\detect_picture.jpg'
    elif choice == '3':
        # 摄像头（默认摄像头索引为0）
        source = 0
    else:
        print("无效的选项！")
        exit()

    # 调用函数进行预测
    results = model_predict(source)
    print(f"最终预测结果: {results}")  # 调试信息
