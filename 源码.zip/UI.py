import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QRadioButton, QTextEdit, QFileDialog, QMessageBox, QStackedWidget, QGridLayout
from PyQt5.QtGui import QImage, QPixmap
from PyQt5.QtCore import QTimer, Qt
from detect import model_predict
import cv2
import numpy as np
import os

class Application(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("检测界面")
        self.setGeometry(100, 100, 800, 600)

        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        self.layout = QVBoxLayout()
        self.central_widget.setLayout(self.layout)

        # 使用QStackedWidget来管理不同的界面
        self.stacked_widget = QStackedWidget()
        self.layout.addWidget(self.stacked_widget)

        # 用户登录部分
        self.login_frame = QWidget()
        self.login_layout = QVBoxLayout()
        self.login_frame.setLayout(self.login_layout)

        # 设置背景颜色
        self.login_frame.setStyleSheet("background-color: #f0f0f0;")

        # 添加标题
        self.title_label = QLabel("欢迎登录")
        self.title_label.setStyleSheet("font-size: 24px; font-weight: bold; color: #333;")
        self.title_label.setAlignment(Qt.AlignCenter)
        self.login_layout.addWidget(self.title_label)

        # 使用网格布局来排列输入框和按钮
        self.form_layout = QGridLayout()
        self.form_layout.setSpacing(15)
        self.form_layout.setContentsMargins(20, 20, 20, 20)

        self.username_label = QLabel("用户名:")
        self.username_label.setStyleSheet("font-size: 16px; color: #555;")
        self.username_entry = QLineEdit()
        self.username_entry.setStyleSheet("font-size: 16px; padding: 10px;")
        self.username_entry.setPlaceholderText("请输入用户名")

        self.password_label = QLabel("密码:")
        self.password_label.setStyleSheet("font-size: 16px; color: #555;")
        self.password_entry = QLineEdit()
        self.password_entry.setStyleSheet("font-size: 16px; padding: 10px;")
        self.password_entry.setPlaceholderText("请输入密码")
        self.password_entry.setEchoMode(QLineEdit.Password)

        self.login_button = QPushButton("登录")
        self.login_button.setStyleSheet("font-size: 16px; padding: 10px; background-color: #007bff; color: white; border-radius: 5px;")
        self.login_button.clicked.connect(self.login)

        self.form_layout.addWidget(self.username_label, 0, 0)
        self.form_layout.addWidget(self.username_entry, 0, 1)
        self.form_layout.addWidget(self.password_label, 1, 0)
        self.form_layout.addWidget(self.password_entry, 1, 1)
        self.form_layout.addWidget(self.login_button, 2, 0, 1, 2)

        self.login_layout.addLayout(self.form_layout)

        self.stacked_widget.addWidget(self.login_frame)

        # 功能选择部分
        self.function_frame = QWidget()
        self.function_layout = QVBoxLayout()
        self.function_frame.setLayout(self.function_layout)

        # 设置背景颜色
        self.function_frame.setStyleSheet("background-color: #f0f0f0;")

        # 添加标题
        self.function_title_label = QLabel("功能选择")
        self.function_title_label.setStyleSheet("font-size: 24px; font-weight: bold; color: #333;")
        self.function_title_label.setAlignment(Qt.AlignCenter)
        self.function_layout.addWidget(self.function_title_label)

        self.source_label = QLabel("路径:")
        self.source_entry = QLineEdit()
        self.source_button = QPushButton("选择文件")
        self.source_button.clicked.connect(self.select_source)
        self.source_button.setEnabled(True)  # 初始化按钮为启用状态
        self.selecting_source = False  # 添加标志位

        self.function_var = "image"
        self.image_radio = QRadioButton("预测图")
        self.image_radio.setChecked(True)
        self.image_radio.toggled.connect(lambda: self.set_function("image"))
        self.camera_radio = QRadioButton("实时摄像")
        self.camera_radio.toggled.connect(lambda: self.set_function("camera"))

        self.predict_button = QPushButton("开始检测")
        self.predict_button.clicked.connect(self.predict)

        # 增加间距
        self.function_layout.addSpacing(20)
        self.function_layout.addWidget(self.source_label)
        self.function_layout.addWidget(self.source_entry)
        self.function_layout.addWidget(self.source_button)
        self.function_layout.addSpacing(10)
        self.function_layout.addWidget(self.image_radio)
        self.function_layout.addWidget(self.camera_radio)
        self.function_layout.addSpacing(10)
        self.function_layout.addWidget(self.predict_button)
        self.function_layout.addSpacing(20)

        self.stacked_widget.addWidget(self.function_frame)

        # 效果展示部分
        self.result_frame = QWidget()
        self.result_layout = QVBoxLayout()
        self.result_frame.setLayout(self.result_layout)

        self.result_label = QLabel("检测结果:")
        self.result_text = QTextEdit()
        self.result_text.setReadOnly(True)

        self.result_layout.addWidget(self.result_label)
        self.result_layout.addWidget(self.result_text)

        # 实时摄像显示部分
        self.camera_label = QLabel()
        self.camera_label.setVisible(False)
        self.result_layout.addWidget(self.camera_label)

        self.timer = QTimer()
        self.timer.timeout.connect(self.update_frame)

        # 添加用于显示图片的 QLabel
        self.image_label = QLabel(self)
        self.image_label.setVisible(False)
        self.result_layout.addWidget(self.image_label)

        self.return_button = QPushButton("返回")
        self.return_button.clicked.connect(self.return_to_function_frame)
        self.result_layout.addWidget(self.return_button)

        self.stacked_widget.addWidget(self.result_frame)

    def login(self):
        username = self.username_entry.text()
        password = self.password_entry.text()
        if username == "admin" and password == "password":  # 简单的登录验证
            QMessageBox.information(self, "登录成功", "欢迎使用!")
            self.stacked_widget.setCurrentIndex(1)  # 切换到功能选择界面
        else:
            QMessageBox.critical(self, "登录失败", "用户名或密码错误!")

    def select_source(self):
        if self.selecting_source:
            return  # 如果已经在选择文件中，直接返回

        self.selecting_source = True  # 设置标志位为True，表示正在选择文件
        self.source_button.setEnabled(False)  # 禁用按钮

        if self.function_var == "image":
            file_path, _ = QFileDialog.getOpenFileName(self, "选择图像文件", "", "Image files (*.jpg *.jpeg *.png)")
        else:
            file_path = ""
        self.source_entry.setText(file_path)

        self.selecting_source = False  # 设置标志位为False，表示选择文件完成
        self.source_button.setEnabled(True)  # 启用按钮

    def set_function(self, function):
        self.function_var = function
        if self.function_var == "camera":
            self.source_entry.setVisible(False)
            self.source_button.setVisible(False)
            self.image_label.setVisible(False)  # 隐藏预测图
            self.camera_label.setVisible(True)  # 显示摄像头
        else:
            self.source_entry.setVisible(True)
            self.source_button.setVisible(True)
            self.image_label.setVisible(True)  # 显示预测图
            self.camera_label.setVisible(False)  # 隐藏摄像头
            if hasattr(self, 'cap') and self.cap.isOpened():
                self.timer.stop()
                self.cap.release()
                self.camera_label.setVisible(False)  # 确保摄像头标签不可见

    def predict(self):
        if self.function_var == "camera":
            self.real_time_predict()
        else:
            source = self.source_entry.text()
            if source:
                try:
                    # 调用模型进行预测
                    save_path = model_predict(source, project='runs/predict', name='exp')  # 修改: 添加 project 和 name 参数
                    print(f"预测结果保存路径: {save_path}")  # 添加日志信息
                    # 加载预测后的图片并显示
                    if isinstance(save_path, str) and os.path.exists(save_path):
                        # 清除之前的显示内容
                        self.result_text.clear()
                        self.image_label.setVisible(True)
                        pixmap = QPixmap(save_path)
                        self.image_label.setPixmap(pixmap)
                        self.image_label.setScaledContents(True)  # 确保图像缩放以适应标签
                    elif isinstance(save_path, np.ndarray):
                        self.result_text.clear()
                        self.image_label.setVisible(True)
                        frame = cv2.cvtColor(save_path, cv2.COLOR_BGR2RGB)
                        h, w, ch = frame.shape
                        bytes_per_line = ch * w
                        qt_image = QImage(frame.data, w, h, bytes_per_line, QImage.Format_RGB888)
                        pixmap = QPixmap.fromImage(qt_image)
                        self.image_label.setPixmap(pixmap)
                        self.image_label.setScaledContents(True)  # 确保图像缩放以适应标签
                    else:
                        QMessageBox.critical(self, "错误", "无法加载预测结果图片!")
                        self.result_text.setText("无法加载预测结果图片!")  # 添加错误信息到result_text
                except Exception as e:
                    QMessageBox.critical(self, "错误", f"预测过程中发生错误: {str(e)}")
                    self.result_text.setText(f"预测过程中发生错误: {str(e)}")  # 添加错误信息到result_text
                finally:
                    self.stacked_widget.setCurrentIndex(2)  # 切换到结果展示界面
            else:
                QMessageBox.critical(self, "输入错误", "请输入路径!")
                self.result_text.setText("请输入路径!")  # 添加错误信息到result_text

    def real_time_predict(self):
        self.cap = cv2.VideoCapture(0)
        if not self.cap.isOpened():
            QMessageBox.critical(self, "错误", "无法打开摄像头")
            return

        # 添加调试信息
        print("摄像头已打开")

        self.camera_label.setVisible(True)
        self.timer.start(30)
        self.stacked_widget.setCurrentIndex(2)  # 切换到结果展示界面

    def update_frame(self):
        ret, frame = self.cap.read()
        if not ret:
            self.timer.stop()
            self.cap.release()
            self.camera_label.setVisible(False)
            return

        # 调用模型进行预测
        results = model_predict(frame, project='runs/predict', name='exp')

        # 检查是否返回的是带有标注的帧
        if isinstance(results, np.ndarray):
            frame = results

        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        h, w, ch = frame.shape
        bytes_per_line = ch * w
        qt_image = QImage(frame.data, w, h, bytes_per_line, QImage.Format_RGB888)
        pixmap = QPixmap.fromImage(qt_image)
        self.camera_label.setPixmap(pixmap)
        self.camera_label.setScaledContents(True)  # 确保图像缩放以适应标签

        # 添加检测结果文本
        self.result_text.setText("实时检测中...")  # 添加实时检测信息到result_text

    def return_to_function_frame(self):
        # 结束实时摄像
        if hasattr(self, 'cap') and self.cap.isOpened():
            self.timer.stop()
            self.cap.release()
            self.camera_label.setVisible(False)

        # 切换到功能选择界面
        self.stacked_widget.setCurrentIndex(1)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = Application()
    window.show()  # 确保主窗口显示
    sys.exit(app.exec_())
